// Porta unica ao banco do marketplace (integration_providers +
// integration_provider_installs).
import { Injectable } from '@nestjs/common';
import { Prisma, ProviderCategory } from '@prisma/client';
import { PrismaService } from '../../../shared/prisma/prisma.service';

@Injectable()
export class MarketplaceRepository {
  constructor(private readonly prisma: PrismaService) {}

  // ─── ProviderDefinition (catalogo) ──────────────────
  findDefinitions(filters: { category?: ProviderCategory; search?: string; onlyActive?: boolean }) {
    const where: Prisma.ProviderDefinitionWhereInput = {};
    if (filters.onlyActive) where.is_active = true;
    if (filters.category) where.category = filters.category;
    if (filters.search) {
      where.OR = [
        { name: { contains: filters.search, mode: 'insensitive' } },
        { description: { contains: filters.search, mode: 'insensitive' } },
        { key: { contains: filters.search, mode: 'insensitive' } },
      ];
    }
    return this.prisma.providerDefinition.findMany({ where, orderBy: { name: 'asc' } });
  }

  findDefinitionByKey(key: string) {
    return this.prisma.providerDefinition.findUnique({ where: { key } });
  }

  // ─── ProviderInstall (da instância) ─────────────────
  findInstalls() {
    return this.prisma.providerInstall.findMany();
  }

  findInstall(providerKey: string) {
    return this.prisma.providerInstall.findFirst({ where: { provider_key: providerKey } });
  }

  createInstall(providerKey: string, installedBy: string | null) {
    return this.prisma.providerInstall.create({
      data: { provider_key: providerKey, installed_by: installedBy },
    });
  }

  deleteInstall(id: string) {
    return this.prisma.providerInstall.delete({ where: { id } });
  }

  /** Conexões não desativadas do provider local (bloqueia uninstall). */
  countActiveConnections(providerKey: string) {
    return this.prisma.connection.count({
      where: {
        provider_key: providerKey,
        status: { not: 'DISABLED' },
      },
    });
  }
}
